
# Autonomous Facebook Publishing Flow

1. Generate multi-day content queue
2. Export to Google Sheet
3. Notify Telegram if image needed
4. User fills image_url
5. User approves post
6. Publisher daemon schedules/publishes
7. Collector gathers results
8. Learning engine analyzes performance
9. Weekly assessment generated
10. Future posts optimized

# Alysha Strategy Standard — AI Marketing Brain

## Purpose

This document defines the strategy quality standard for the AI Marketing Brain.

The goal is to make sure every Strategy output is deep enough to power real creative production.

Strategy must not be generic.
Strategy must be usable by the Creative Engine immediately.

---

## Core Flow

Research
→ Insight
→ Strategy
→ Creative

Strategy is the bridge between insight and creative execution.

Research = market signal  
Insight = meaning  
Strategy = decision  
Creative = execution

---

## Required Strategy Output Blocks

Every final `strategy_output.json` should contain the following blocks.

---

## 1. Target Persona

The persona must be usable as a direct ad callout.

Good:

```text
For sons and daughters buying Mother's Day gifts
Bad:

Adults aged 25–45

Required fields:

{
  "persona": "string",
  "why_this_persona": "string",
  "source_insights": ["string"],
  "priority": "high | medium | low"
}
2. Customer Psychology

This block explains the psychological conflict.

Required fields:

{
  "problem": "string",
  "tension": "string",
  "current_belief": "string",
  "desired_belief": "string"
}

Definitions:

problem: what the customer struggles with
tension: emotional conflict or friction
current_belief: what they believe now
desired_belief: what they need to believe to buy

Example:

{
  "problem": "People don't know what gift mom will actually use",
  "tension": "They want to be thoughtful but usually end up buying something generic",
  "current_belief": "A nice-looking gift is enough",
  "desired_belief": "A good gift is something she actually uses every day"
}
3. Strategy Map

This block maps the strategy to persona, pain, desire, funnel stage, and message role.

Required fields:

{
  "persona": "string",
  "pain_bucket": "string",
  "desire_bucket": "string",
  "awareness_stage": "unaware | problem_aware | solution_aware | product_aware | most_aware",
  "funnel_role": "cold | warm | retargeting",
  "message_role": "educate | reframe | compare | convert"
}

Definitions:

pain_bucket: the pain category
desire_bucket: the desired outcome category
awareness_stage: how aware the audience is
funnel_role: where this message fits in the funnel
message_role: what the message needs to do
4. Priority Angles

Angles are strategic ways to tell the story.

Required fields:

{
  "angle": "string",
  "why_it_should_work": "string",
  "supporting_insights": ["string"],
  "supporting_brands": ["string"],
  "ad_expression": "string",
  "priority": "high | medium | low"
}

Rules:

Every angle must be based on insights.
Every angle must reference supporting brands or evidence.
Every angle must include an ad_expression.
ad_expression must be usable as a hook or creative direction immediately.

Example:

{
  "angle": "Practical gift vs useless gift",
  "ad_expression": "Not another gift that sits on a shelf. Something she actually uses every morning."
}
5. Hook Guidance

This block helps the Creative Engine write stronger hooks.

Required fields:

{
  "hook_tactic": "string",
  "hook_voice": "string",
  "awareness_stage": "string",
  "why_it_stops_scroll": "string"
}

Suggested hook tactics:

direct_callout
problem_callout
contrast
belief_shift
specific_observation
failed_solution
before_after
status_identity
curiosity_gap
emotional_truth

Suggested hook voices:

direct_response
native_social
ugc
emotional_story
educational
contrarian
relatable
6. Core Message

This block defines what the campaign should communicate.

Required fields:

{
  "message": "string",
  "why_it_matters": "string",
  "emotional_driver": "string",
  "belief_shift_embedded": "string"
}

Rules:

The message must not merely describe the product.
The message must embed the belief shift.
The message should be simple enough for creative execution.
7. Offer Strategy

This block explains how the offer should be used.

Required fields:

{
  "offer_use": "string",
  "why_it_works": "string",
  "risk_reduced": "string"
}

Rules:

Offer should reduce risk or increase confidence.
Offer should support the strategy, not replace it.
8. Reason to Believe

This block provides proof points.

Required fields:

{
  "proof_point": "string",
  "why_believable": "string",
  "source": "brand | product | research | insight | voc"
}

Rules:

Proof must be concrete.
Avoid vague claims.
Use product truth, brand truth, research, insight, or VOC.
9. Mechanism

This block explains why the product solves the problem.

Required fields:

{
  "mechanism": "string",
  "why_it_solves_problem": "string"
}

Example:

{
  "mechanism": "6 roast levels tasting set",
  "why_it_solves_problem": "Removes guesswork and lets the recipient find their preferred strength"
}
10. VOC Summary

This block extracts Voice of Customer from real customer feedback.

Required fields:

{
  "customer_phrase": "string",
  "pain": "string",
  "objection": "string",
  "buying_trigger": "string",
  "desired_outcome": "string",
  "how_to_use_in_creative": "string"
}

Rules:

Use exact customer language when possible.
Do not invent feedback.
If feedback is unclear, mark unclear fields as "unclear".
VOC should improve hooks, objections, proof, and creative direction.
11. Creative Mechanics

This block defines the creative execution mechanism.

Required fields:

{
  "mechanic": "string",
  "why_this_mechanic": "string",
  "paired_angle": "string"
}

Suggested mechanics:

split_screen
before_after
pov
listicle
testimonial
product_demo
problem_solution
comparison
morning_routine
gift_reveal
comment_reply
myth_busting
12. Visual Formats

This block defines the best format for the creative.

Required fields:

{
  "format": "string",
  "best_for": "ads | organic | retargeting | awareness | conversion",
  "production_notes": "string"
}

Suggested formats:

static_image
carousel
ugc_video
product_demo_video
reels_script
short_form_video
meme_post
comparison_static
testimonial_static
landing_page_section
13. Creative Direction

This block gives production-ready direction.

Required fields:

{
  "concept": "string",
  "visual_direction": "string",
  "hook_direction": "string",
  "best_for": "image | video | landing_page | email | ad_copy"
}

Rules:

Creative direction must be specific.
A designer or video editor should understand what to make.
Avoid vague directions like “make it emotional.”
14. Do Not Do

This block protects brand positioning.

Required format:

[
  "string"
]

Examples:

Do not describe AODAI as flavored coffee.
Do not mix AODAI positioning with Nonla flavor messaging.
Do not focus on luxury over usefulness.
Strategy Pass Criteria

A strategy output passes if:

[ ] Target persona can be used as ad callout
[ ] Problem is specific
[ ] Tension is emotionally clear
[ ] Current belief and desired belief are explicit
[ ] Strategy map includes awareness stage
[ ] Pain bucket and desire bucket are clear
[ ] Priority angles are supported by insight or evidence
[ ] Each angle has ad_expression
[ ] Hook guidance exists
[ ] Core message embeds belief shift
[ ] Offer strategy reduces risk or increases confidence
[ ] Reason to believe is concrete
[ ] Mechanism explains product feature → problem solved
[ ] VOC summary is used if feedback exists
[ ] Creative mechanics are specific
[ ] Visual formats are production-ready
[ ] Do-not-do guardrails are included
Final Rule

If the Strategy output cannot help the Creative Engine produce ads, posts, videos, or images immediately, the Strategy output is not ready.
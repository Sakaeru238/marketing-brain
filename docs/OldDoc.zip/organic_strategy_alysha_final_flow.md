# Organic Strategy Layer — Alysha-Compliant Final Flow

## Purpose
This patch makes daily organic generation pass through an Alysha-compliant organic strategy review layer before any organic posts are generated.

## Final Runtime Flow

```text
Alysha Strategy Output
→ Audience Psychology Layer
→ Social Engagement Layer
→ KPI Pressure Layer
→ Organic Execution Strategy
→ Organic Content Generator
→ Google Sheets Organic_Posts export
```

Publishing, Results Collector, and Learning / Optimization remain downstream jobs and are not broken by this patch.

## Source of Truth
- `data/output/strategy_output.json` is treated as the Alysha Strategy Engine source of truth.
- Organic strategy is NOT a new master strategy.
- It is an organic execution translation of the Alysha strategy.

## Protected Alysha Fields
Organic review/generation may not rewrite:
- campaign direction alignment
- target persona
- customer psychology
- core message
- offer strategy
- reason to believe
- mechanism
- do_not_do rules

## Allowed Organic Expansion
Organic execution may expand only:
- audience slice
- scenario
- hook
- format
- tone
- content archetype
- posting angle
- SEO wording
- reaction trigger
- social engagement tactics
- KPI pressure actions
- event execution policy
- daily learning adjustments

## Event Rule via Page_Channel_Library.notes
- Empty notes → `evergreen_growth`
- Non-empty notes → `event_active` or `event_transition`

No artificial event IDs or campaign IDs are created. All identifiers come from Page_Channel_Library.

## Output Paths
```text
data/output/{brand_id}/{page_id}/{campaign_id}/organic_posts/
  organic_strategy_output.json
  organic_output.json
```

## Daily Review + Telegram Notification
Every daily organic generation run reviews the organic strategy before content generation.

If a meaningful update occurs, Telegram receives:
- brand / page / campaign
- strategy mode
- update type
- what changed in Vietnamese
- reason in Vietnamese

No Telegram strategy update is sent if no meaningful change occurred.

## Google Sheets Compatibility
The Organic Content Generator still outputs the same `organic_posts[]` fields expected by the existing Google Sheets exporter. The `Organic_Posts` append job continues to work unchanged.

## Manual Run
```bash
python -m core.jobs.daily_generate_organic_job
```

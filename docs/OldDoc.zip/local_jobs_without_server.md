# Running Jobs Locally Before Server Deployment

Daily manual flow:

cd ~/Source/marketing-brain
source venv/bin/activate

python -m test.check_rolling_content_queue
python -m test.schedule_facebook_posts_from_gsheet
python -m test.collect_facebook_post_results
python -m test.run_page_assessment_only
python -m test.export_page_assessment_to_gsheet

Publisher every 10 minutes with cron:

*/10 * * * * /Users/YOUR_USERNAME/Source/marketing-brain/run_publisher_job.sh >> /Users/YOUR_USERNAME/Source/marketing-brain/logs/publisher_cron.log 2>&1

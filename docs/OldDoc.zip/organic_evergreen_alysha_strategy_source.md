# Organic Evergreen Alysha Strategy Source Patch

This patch fixes the upstream strategy leak where organic posts could stay trapped in an old event strategy even when `Page_Channel_Library.notes` no longer requested an event.

## New upstream source layer

```text
Page_Channel_Library + KPI context + reference Alysha strategy
→ OrganicAlyshaSourceService
→ organic_alysha_source_output.json
→ OrganicStrategyService
→ organic_strategy_output.json
→ OrganicGenerationService
```

## Source-mode rule

- notes blank or normal free-text note → `evergreen_growth`
- notes starting with `event:` → event-aware organic source

## New file generated per page/campaign

```text
data/output/{brand_id}/{page_id}/{campaign_id}/organic_posts/organic_alysha_source_output.json
```

## Why this matters

The global `data/output/strategy_output.json` may still contain a seasonal strategy, such as Mother's Day. This patch uses that file only as a reference source for brand/product truths and generates a page/campaign-scoped organic Alysha source that is appropriate for the current organic mode.

## Expected behavior after applying

With empty notes:
- `organic_alysha_source_output.json.source_mode = evergreen_growth`
- `organic_strategy_output.json.strategy_mode = evergreen_growth`
- newly generated organic posts should not contain expired event language such as Mother's Day

With `notes = event: Mother's Day`:
- the organic Alysha source becomes event-aware
- the organic strategy can use event execution policy while remaining Alysha-compliant

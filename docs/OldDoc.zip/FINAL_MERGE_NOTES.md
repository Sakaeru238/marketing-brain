# Final Merge Notes V10

This package is built from the uploaded existing source files.

Kept existing responsibilities:

- `core/exporters/google_sheets_exporter.py` remains the only Google Sheets exporter.
- `core/publishers/facebook_page_publisher.py` remains the Facebook publisher.
- `core/publishers/facebook_graph_client.py` remains the Graph API client.
- `core/notifications/telegram_notifier.py` remains the Telegram notifier.

Added only missing production source files:

- `core/services/organic_generation_service.py`
- `core/jobs/daily_generate_organic_job.py`
- `core/campaign/campaign_kpi_calculator.py`
- `core/campaign/page_campaign_context_loader.py`
- `core/prompts/prompt_loader.py`

No duplicate `google_sheets_organic_appender.py`.

Main command:

```bash
python -m core.jobs.daily_generate_organic_job
```

This command:
1. reads Page_Channel_Library
2. calculates KPI from start_day/end_day/duration
3. injects campaign_kpi_context into prompt
4. generates organic posts
5. appends Organic_Posts through existing GoogleSheetsExporter
6. sends Telegram notification

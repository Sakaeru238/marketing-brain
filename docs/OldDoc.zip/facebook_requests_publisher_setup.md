# Facebook Requests Publisher Setup

## Architecture

This publisher uses:

```text
requests -> Meta Graph API
```

It does not use MCP as the core publisher.

## Default Safety

Dry-run is ON by default:

```bash
FACEBOOK_PUBLISH_DRY_RUN=true
```

Dry-run validates rows and updates Google Sheet with `scheduled_dry_run`.

## Required Google Sheet fields

In `Organic_Posts`:

```text
post_id
brand_id
page_id
platform_id
post_text
image_url
post_status
publisher_status
facebook_post_id
publisher_error
scheduled_datetime_utc
published_or_scheduled_at
```

## Test dry-run

Set one row:

```text
post_status = approved
publisher_status = empty
scheduled_datetime_utc = future UTC time
image_url = empty for text-only test
```

Run:

```bash
python -m test.schedule_facebook_posts_from_gsheet
```

## Real publish

Only after dry-run passes:

```bash
export FACEBOOK_PUBLISH_DRY_RUN=false
export META_PAGE_ID="your_meta_page_id"
export META_PAGE_ACCESS_TOKEN="your_page_access_token"
export META_GRAPH_VERSION="v20.0"
python -m test.schedule_facebook_posts_from_gsheet
```

## Image post

For image posts, `image_url` must be public HTTPS URL.

Local paths and private Google Drive links will fail.

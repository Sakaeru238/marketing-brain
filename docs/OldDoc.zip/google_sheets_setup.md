# Google Sheets Export Setup

## Design

- 1 Google Sheet file = 1 brand
- 1 brand can have many pages/channels
- Routing is controlled by `config/google_sheet_routing.json`
- Export goes to tab `Organic_Posts`
- Result metrics are later entered into `Organic_Results`
- Daily learning is later written to `Daily_Learning_Log`

## Install packages

```bash
pip install gspread google-auth gspread-formatting
```

Or append the contents of `requirements_google_sheets_additions.txt` to your main `requirements.txt`.

## Credentials

Create a Google service account and save the credential JSON as:

```text
secrets/google_service_account.json
```

Share your Google Sheet with the service account email.

Optional `.env`:

```env
GOOGLE_SHEETS_CREDENTIALS_FILE=secrets/google_service_account.json
```

## Routing

Edit `config/google_sheet_routing.json`:

```json
{
  "routes": [
    {
      "brand_id": "AODAI",
      "page_id": "AODAI_FB_US",
      "platform_id": "facebook",
      "google_sheet_url": "https://docs.google.com/spreadsheets/d/YOUR_AODAI_SHEET_ID/edit",
      "tabs": {
        "brand_config": "Brand_Config",
        "pages": "Page_Channel_Library",
        "posts": "Organic_Posts",
        "results": "Organic_Results",
        "learning": "Daily_Learning_Log"
      },
      "status": "active"
    }
  ]
}
```

## Run

Generate organic output:

```bash
python -m test.run_organic_only
```

Export to Google Sheet:

```bash
python -m test.export_organic_to_gsheet
```

## Organic_Posts columns

- organic_run_id
- post_id
- created_at
- brand_id
- niche_id
- page_id
- platform_id
- page_url
- campaign_id
- post_format
- content_role
- content_pillar
- angle_used
- hook_type
- product_mention_level
- hook
- post_text
- engagement_prompt
- chatgpt_image_prompt
- post_status
- published_date
- post_url
- notes_user

Removed fields:

- why_this_post
- risk_note

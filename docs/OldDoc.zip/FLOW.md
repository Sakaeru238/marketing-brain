# AGENTS.md — AI Marketing Brain

## Current project goal

We are building an AI Marketing Brain.

The system flow is:

Brand Intake
→ Research
→ Insight
→ Strategy
→ Creative

## Current status

Brand Intake is working.

Research Market Prompt is working and returns valid JSON:
- competitor_findings
- ad_findings
- sources

Insight Prompt is working and returns valid JSON:
- core_insights
- winning_angles
- emotional_drivers
- gift_psychology_patterns
- ad_pattern_library

The next work should continue from the Insight Engine stage.

## Non-negotiable architecture rules

- Prompts must stay in `data/prompts/`.
- Do not hardcode long prompts inside pipeline code.
- Test files should not change production logic.
- Each stage does only one job:
  - Research = collect market/ad intelligence.
  - Insight = extract patterns from research.
  - Strategy = decide campaign direction.
  - Creative = generate ad assets/copy.
- Keep data traceable: outputs should include brand/source context where relevant.

## Important files

Research prompt:
`data/prompts/research/research_market_prompt.txt`

Insight prompt:
`data/prompts/insight/insight_extraction_prompt.txt`

Research dummy data for insight test:
`data/output/research_output.json`

Research test:
`test/test_market_prompt.py`

Insight test:
`test/test_insight_prompt.py`

Pipeline files:
`core/pipeline/research_pipeline.py`
`core/pipeline/insight_pipeline.py`
`core/pipeline/strategy_pipeline.py`
`core/pipeline/creative_pipeline.py`
`core/pipeline/master_pipeline.py`

## Current next task

Improve the Insight Engine schema so every insight is traceable.

Insight output should include:
- the insight or pattern
- supporting brands
- based_on_angles or evidence_from
- confidence
- why_it_works / why_it_matters

Do not move to Strategy until Insight output is traceable and test passes.

## Commands

Run research prompt test:

```bash
python -m test.test_market_prompt
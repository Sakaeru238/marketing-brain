
# Final System Architecture

## MASTER FLOW

Alysha Strategy Output
↓
Organic Planner
↓
Multi-Day Content Queue Generator
↓
Google Sheet Export
↓
Telegram Notify (if image/action needed)
↓
Approval Workflow
↓
Publisher Daemon
↓
Facebook Graph API
↓
Results Collector
↓
Organic_Results
↓
Learning Engine
↓
Weekly Page Assessment
↓
Optimization Suggestions

---

# KEY SYSTEMS

## 1. Strategy Anchor Layer

AI may:
- expand audience slices
- expand hooks
- expand scenarios
- expand archetypes

AI may NOT:
- rewrite positioning
- leave emotional territory
- invent unrelated audience

---

## 2. Reaction Engine

Every post must intentionally create:
- comment
- share
- save
- debate
- relatability
- identity reaction
- tagging behavior

---

## 3. Content Archetypes

- emotional
- humor
- educational
- aspirational
- product

---

## 4. SEO Layer

Uses:
- brand SEO keywords
- trend keywords
- platform-native semantic keywords

Natural integration only.

---

## 5. Schedule Intelligence

Scheduling is NOT fixed.

Scheduling depends on:
- audience behavior
- content archetype
- timezone
- historical page learning
- emotional context

---

## 6. Rolling Content Queue

System must maintain:
3–7 days future content buffer.

If queue too short:
→ auto generate more future posts.

---

## 7. Publisher Daemon

Runs every 5 minutes.

Publishes:
approved posts
where scheduled_datetime_utc <= now + threshold

---

## 8. Results Collector

Pull:
- likes
- comments
- shares
- reactions
- reach
- impressions
- engagement

Store in Organic_Results.

---

## 9. Learning Engine

Learns:
- best hooks
- best posting windows
- best archetypes
- best interaction triggers
- best audience slices
- best SEO combinations

WITHOUT rewriting Alysha strategy.

---

## 10. Telegram Notification Layer

Notify user when:
- image creation needed
- post approval needed
- publish success/fail
- token expired
- results ready
- weekly learning ready

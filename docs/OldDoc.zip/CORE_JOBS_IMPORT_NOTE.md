# Core Jobs Import Note

Project root job folder is:

```text
core/jobs/
```

Therefore production commands must use:

```bash
python -m core.jobs.daily_generate_organic_job
python -m core.jobs.daily_schedule_facebook_job
python -m core.jobs.facebook_results_collector_job
```

Do not create or use root-level `jobs/`.

# MacBook Cron Setup Final

## Test manually first

```bash
cd ~/Source/marketing-brain
source venv/bin/activate
python -m core.jobs.daily_generate_organic_job
```

## Cron

```cron
0 11 * * * cd /Users/YOUR_USERNAME/Source/marketing-brain && /bin/bash -lc 'source venv/bin/activate && python -m core.jobs.daily_generate_organic_job >> logs/generate_organic.log 2>&1'

0 16 * * * cd /Users/YOUR_USERNAME/Source/marketing-brain && /bin/bash -lc 'source venv/bin/activate && python -m core.jobs.daily_schedule_facebook_job >> logs/facebook_schedule.log 2>&1'

0 22 * * * cd /Users/YOUR_USERNAME/Source/marketing-brain && /bin/bash -lc 'source venv/bin/activate && python -m core.jobs.facebook_results_collector_job >> logs/facebook_results.log 2>&1'
```

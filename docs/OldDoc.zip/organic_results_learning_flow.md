# Organic Results + Learning Flow

## Manual command

```bash
python -m core.jobs.daily_collect_organic_results_job
```

## What the job does

1. Reads active routes from `config/google_sheet_routing.json`.
2. Reads `Organic_Posts` rows that have:
   - `platform_id = facebook`
   - a real `facebook_post_id` (not `dryrun_*`)
3. Calls Meta Graph API:
   - Object details (Post or Photo schema)
   - Post insights metrics:
     - `post_impressions_unique` -> `reach`
     - `post_impressions` -> `impressions`
     - `post_clicks` -> `clicks`
4. Calculates:
   - `engagement_rate = (likes + comments + shares + clicks) / reach * 100`
5. Writes/upserts `Organic_Results` by:
   - `date + facebook_post_id`
6. Produces AI learning:
   - `ai_result_summary`
   - `ai_learning`
   - `ai_next_action`
7. Updates/upserts `Daily_Learning_Log` by:
   - `date + brand_id + page_id + platform_id + campaign_id`
8. Saves local learning memory to:
   - `data/knowledge/organic_learning/{brand_id}/{brand_id}_{page_id}.jsonl`
9. The next Organic Generation run reads recent local learning memory and injects it into the generation input.

## Facebook metric handling

For Facebook:

- `saves = "-"`
- `follows = "-"`

The columns remain in the schema for future platforms where these metrics may exist.

## Daily_Learning_Log schema note

The old schema had a duplicate header:

- `weak_content_roles_ai` appeared twice.

The patch normalizes the second duplicate to:

- `weak_pillars_ai`

This prevents content-role and pillar learning from being merged incorrectly.

## Required env

```env
META_PAGE_ACCESS_TOKEN=...
META_GRAPH_VERSION=v20.0
RESULTS_DATE_TIMEZONE=Asia/Ho_Chi_Minh
```

Optional:

```env
ORGANIC_RESULTS_MAX_POSTS=1
ORGANIC_LEARNING_CONTEXT_LIMIT=20
```

## Important runtime behavior

- The collector will not write incomplete result rows if required Facebook insight metrics are missing.
- If a row fails Graph API or insights retrieval, it appears in `row_errors` in terminal JSON output.
- AI learning uses Claude when configured; otherwise it falls back to deterministic rule-based learning strings.


# Telegram Setup

## Required .env

TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=

## Create Bot

1. Open Telegram
2. Search BotFather
3. /newbot
4. Copy token

## Get Chat ID

Send any message to bot.

Open:
https://api.telegram.org/bot<BOT_TOKEN>/getUpdates

Copy chat.id.

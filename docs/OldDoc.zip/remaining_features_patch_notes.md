# Organic Remaining Features Patch

## Test order

```bash
python -m test.run_organic_only
python -m test.export_organic_to_gsheet
python -m test.run_page_assessment_only
python -m test.export_page_assessment_to_gsheet
python -m test.schedule_facebook_posts_from_gsheet
```

Facebook publishing is dry-run by default.

To enable real publishing:

```bash
export FACEBOOK_PUBLISH_DRY_RUN=false
export META_PAGE_ID=your_page_id
export META_PAGE_ACCESS_TOKEN=your_page_access_token
```

On Windows PowerShell:

```powershell
$env:FACEBOOK_PUBLISH_DRY_RUN="false"
$env:META_PAGE_ID="your_page_id"
$env:META_PAGE_ACCESS_TOKEN="your_page_access_token"
```
